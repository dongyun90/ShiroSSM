CREATE VIEW first_view AS
  /* ALGORITHM=UNDEFINED */ (SELECT
                               `school`.`student`.`age`  AS `age`,
                               `school`.`student`.`name` AS `name`
                             FROM `school`.`student`);


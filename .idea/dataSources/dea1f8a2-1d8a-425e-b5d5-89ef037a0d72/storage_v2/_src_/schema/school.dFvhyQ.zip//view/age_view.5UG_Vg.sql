CREATE VIEW age_view AS
  /* ALGORITHM=UNDEFINED */ (SELECT
                               `a`.`department` AS `department`,
                               `b`.`name`       AS `name`
                             FROM `school`.`age` `a`
                               JOIN `school`.`student` `b`
                             WHERE (`a`.`age` = `b`.`age`));

